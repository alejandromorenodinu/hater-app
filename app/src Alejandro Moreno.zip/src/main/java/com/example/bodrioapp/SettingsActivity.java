package com.example.bodrioapp;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class SettingsActivity extends AppCompatActivity {

    SharedPreferences preferencias;
    EditText editTamañoLetra;
    Spinner spinnerIdioma;
    Button btnGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        editTamañoLetra = findViewById(R.id.editTamañoLetra);
        spinnerIdioma = findViewById(R.id.spinnerIdioma);
        btnGuardar = findViewById(R.id.btnGuardar);
        preferencias = getSharedPreferences("mis_preferencias", MODE_PRIVATE);
        cargarPreferencias();
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarPreferencias();
            }
        });
    }
    private void guardarPreferencias() {
        int idiomaPos = spinnerIdioma.getSelectedItemPosition();
        String tamañoLetra = editTamañoLetra.getText().toString();
        SharedPreferences.Editor editor = preferencias.edit();
        editor.putInt("idioma_pos", idiomaPos);
        editor.putString("tamañoLetra", tamañoLetra);
        editor.apply();
        android.widget.Toast.makeText(this,
                getString(R.string.saveConfig),
                android.widget.Toast.LENGTH_SHORT).show();
        aplicarPreferencias();
    }


    private void cargarPreferencias() {
        String idiomaGuardado = preferencias.getString("idioma", "Español");
        String tamañoGuardado = preferencias.getString("tamañoLetra", "14");
        editTamañoLetra.setText(tamañoGuardado);
        for (int i = 0; i < spinnerIdioma.getCount(); i++) {
            if (spinnerIdioma.getItemAtPosition(i).toString().equals(idiomaGuardado)) {
                spinnerIdioma.setSelection(i);
                break;
            }
        }
    }

    private void aplicarPreferencias() {

        SharedPreferences prefs = getSharedPreferences("mis_preferencias", MODE_PRIVATE);
        String idioma = prefs.getString("idioma", "Español");
        Locale locale;
        if (idioma.equals("English")) {
            locale = new Locale("en");
        } else if (idioma.equals("Català")) {
            locale = new Locale("ca");
        } else {
            locale = new Locale("es");
        }
        Locale.setDefault(locale);
        Configuration config = new Configuration(getResources().getConfiguration());
        config.setLocale(locale);
        float fontScale = Float.parseFloat(
                prefs.getString("tamañoLetra", "1.0")
        );
        if (fontScale <= 35) {
            // tengo que dividir entre 10 por un bug rarisimo que no me pasaba en la agenda xd
            config.fontScale = fontScale/10;
            getResources().updateConfiguration(
                    config,
                    getResources().getDisplayMetrics()
            );
        }
        recreate();
    }

}
