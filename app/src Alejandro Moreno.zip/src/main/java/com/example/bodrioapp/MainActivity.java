package com.example.bodrioapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Post> listaPosts;
    private PostAdapter adapter;

    private static final String TAG = "Firebase";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        aplicarTamañoLetra();

        recyclerView = findViewById(R.id.recyclerPosts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listaPosts = new ArrayList<>();
        adapter = new PostAdapter(listaPosts, this);
        recyclerView.setAdapter(adapter);

        leerPosts();

        findViewById(R.id.btnAddPost).setOnClickListener(v -> {
            Intent intent = new Intent(this, CreatePostActivity.class);
            startActivity(intent);
        });
        findViewById(R.id.favoritos).setOnClickListener(v ->
                startActivity(new Intent(this, FavoritosActivity.class)));

        findViewById(R.id.reviewed).setOnClickListener(v ->
                startActivity(new Intent(this, ReviewedActivity.class)));

        findViewById(R.id.ajustes).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));


    }

    private void leerPosts() {

        FirebaseDatabase database = FirebaseDatabase.getInstance(
                "https://reviewsnegativas-ec0fc-default-rtdb.europe-west1.firebasedatabase.app"
        );
        DatabaseReference postsRef = database.getReference("Posts");
        postsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                listaPosts.clear();

                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Post post = postSnapshot.getValue(Post.class);
                    if (post != null) {
                        post.id = postSnapshot.getKey();
                        listaPosts.add(post);
                        Log.d(TAG, "Post cargado: " + post.titulo);
                    }
                }
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(DatabaseError error) {
                Log.e(TAG, "Error leyendo posts", error.toException());
            }
        });
    }
    private void aplicarTamañoLetra() {
        SharedPreferences prefs = getSharedPreferences("mis_preferencias", MODE_PRIVATE);
        float fontScale;
        fontScale = Float.parseFloat(prefs.getString("tamañoLetra", "1.4")) / 10;
        Configuration config = getResources().getConfiguration();
        config.fontScale = fontScale;
        getResources().updateConfiguration(
                config,
                getResources().getDisplayMetrics()
        );
    }

}
