package com.example.bodrioapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class FavoritosActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Post> listaPosts;
    PostAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favoritos);

        recyclerView = findViewById(R.id.recyclerFavoritos);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listaPosts = new ArrayList<>();
        adapter = new PostAdapter(listaPosts, this);
        recyclerView.setAdapter(adapter);

        cargarFavoritos();
    }

    private void cargarFavoritos() {

        BodrioDb dbBodrio = new BodrioDb(this);
        Cursor cursor = dbBodrio.getReadableDatabase().rawQuery("SELECT postId FROM favoritos", null);

        FirebaseDatabase database = FirebaseDatabase.getInstance(
                "https://reviewsnegativas-ec0fc-default-rtdb.europe-west1.firebasedatabase.app"
        );

        while (cursor.moveToNext()) {
            String postId = cursor.getString(0);

            database.getReference("Posts").child(postId)
                    .get()
                    .addOnSuccessListener(snapshot -> {
                        Post post = snapshot.getValue(Post.class);
                        if (post != null) {
                            post.id = postId;
                            listaPosts.add(post);
                            adapter.notifyDataSetChanged();
                        }
                    });
        }

        cursor.close();
    }
}
