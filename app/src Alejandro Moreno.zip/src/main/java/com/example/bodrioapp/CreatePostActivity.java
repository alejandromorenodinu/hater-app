package com.example.bodrioapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreatePostActivity extends AppCompatActivity {

    private EditText edtTitulo, edtDescripcion, edtContenido;
    private Button btnPublicar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtDescripcion = findViewById(R.id.edtDescripcion);
        edtContenido = findViewById(R.id.edtContenido);
        btnPublicar = findViewById(R.id.btnPublicar);

        btnPublicar.setOnClickListener(v -> publicarPost());
    }

    private void publicarPost() {

        String titulo = edtTitulo.getText().toString().trim();
        String descripcion = edtDescripcion.getText().toString().trim();
        String contenido = edtContenido.getText().toString().trim();

        if (titulo.isEmpty() || descripcion.isEmpty() || contenido.isEmpty()) {
            Toast.makeText(this, "Rellena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseDatabase database = FirebaseDatabase.getInstance(
                "https://reviewsnegativas-ec0fc-default-rtdb.europe-west1.firebasedatabase.app"
        );

        DatabaseReference postsRef = database.getReference("Posts");

        String postId = postsRef.push().getKey();

        Post post = new Post(titulo, descripcion, contenido, 0);

        postsRef.child(postId).setValue(post)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Post publicado", Toast.LENGTH_SHORT).show();
                    finish(); // Volver a MainActivity
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error al publicar", Toast.LENGTH_SHORT).show()
                );
    }
}
