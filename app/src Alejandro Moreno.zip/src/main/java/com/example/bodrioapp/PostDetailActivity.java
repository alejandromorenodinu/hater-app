package com.example.bodrioapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class PostDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);

        TextView txtTitulo = findViewById(R.id.txtTituloDetalle);
        TextView txtDescripcion = findViewById(R.id.txtDescripcionDetalle);
        TextView txtContenido = findViewById(R.id.txtContenidoDetalle);
        TextView txtPromedio = findViewById(R.id.txtPromedioDetalle);

        // Recibir datos del Intent
        String titulo = getIntent().getStringExtra("titulo");
        String descripcion = getIntent().getStringExtra("descripcion");
        String contenido = getIntent().getStringExtra("contenido");
        double promedio = getIntent().getDoubleExtra("promedio", 0);
        String postId = getIntent().getStringExtra("postId");

        // Mostrar datos
        txtTitulo.setText(titulo);
        txtDescripcion.setText(descripcion);
        txtContenido.setText(contenido);
        txtPromedio.setText("Valoración: " + promedio);

        RatingBar ratingBar = findViewById(R.id.ratingBar);
        Button btnValorar = findViewById(R.id.btnValorar);

        Button btnFavorito = findViewById(R.id.btnFavorito);

        btnFavorito.setOnClickListener(v -> {

            BodrioDb dbBodrio = new BodrioDb(this);
            SQLiteDatabase db = dbBodrio.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("postId", postId);
            values.put("titulo", titulo);

            db.insertWithOnConflict(
                    "favoritos",
                    null,
                    values,
                    SQLiteDatabase.CONFLICT_IGNORE
            );
        });

        btnValorar.setOnClickListener(v -> {

            float valoracion = ratingBar.getRating();
            if (valoracion == 0) return;

            FirebaseDatabase database = FirebaseDatabase.getInstance(
                    "https://reviewsnegativas-ec0fc-default-rtdb.europe-west1.firebasedatabase.app"
            );

            DatabaseReference comentariosRef = database.getReference("Comentarios");

            // 🔑 crear ID automático
            String comentarioId = comentariosRef.push().getKey();

            HashMap<String, Object> comentario = new HashMap<>();
            comentario.put("postId", postId);                // STRING
            comentario.put("Valoracion", (int) valoracion);  // INT
            comentario.put("timestamp", System.currentTimeMillis());

            comentariosRef.child(comentarioId).setValue(comentario)
                    .addOnSuccessListener(unused -> {
                        // 🔔 confirma que SE GUARDÓ
                        Toast.makeText(this, "Reseña guardada", Toast.LENGTH_SHORT).show();

                        // ahora sí tiene sentido recalcular
                        recalcularPromedio(postId);
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show();
                    });
        });


    }
    private void recalcularPromedio(String postId) {

        FirebaseDatabase database = FirebaseDatabase.getInstance(
                "https://reviewsnegativas-ec0fc-default-rtdb.europe-west1.firebasedatabase.app"
        );

        DatabaseReference comentariosRef = database.getReference("Comentarios");
        DatabaseReference postRef = database.getReference("Posts").child(postId);

        comentariosRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                int suma = 0;
                int cantidad = 0;

                for (DataSnapshot comentarioSnap : snapshot.getChildren()) {

                    // postId SIN tipo fijo
                    Object postIdObj = comentarioSnap.child("postId").getValue();
                    Object valoracionObj = comentarioSnap.child("Valoracion").getValue();

                    if (postIdObj == null || valoracionObj == null) continue;

                    String postIdFirebase = String.valueOf(postIdObj);

                    int valoracion;
                    try {
                        valoracion = Integer.parseInt(String.valueOf(valoracionObj));
                    } catch (NumberFormatException e) {
                        continue;
                    }

                    if (postIdFirebase.equals(postId)) {
                        suma += valoracion;
                        cantidad++;
                    }
                }

                if (cantidad > 0) {
                    double promedio = (double) suma / cantidad;
                    postRef.child("promedio").setValue(promedio);
                    postRef.child("cantidadValoraciones").setValue(cantidad);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // No hacemos nada, evitamos crash
            }
        });
    }

}
